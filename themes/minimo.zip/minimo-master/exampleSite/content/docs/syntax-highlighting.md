---
date: 2017-09-27T12:00:00+06:00
title: Syntax Highlighting
authors: ["muniftanjim"]
categories:
  - features
tags:
  - pygments
  - chroma
slug: syntax-highlighting
---
Hugo uses Chroma as it's built-in syntax-highlighter.

For detailed information about Syntax Highlighting in Hugo, check the [Hugo's Syntax Highlighting Documentation](https://gohugo.io/content-management/syntax-highlighting/).

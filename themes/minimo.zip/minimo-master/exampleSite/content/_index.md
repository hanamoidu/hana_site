---
title: Home
menu: main
weight: -270
---
> Minimalism is not a lack of something. It’s simply the perfect amount of something.
> — Nicholas Burroughs
